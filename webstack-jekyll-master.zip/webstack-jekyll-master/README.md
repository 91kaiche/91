# ➡️ [webstack.0xl2oot.cn](https://webstack.0xl2oot.cn/) - 网址导航

本项目是 [webstack.cc](https://github.com/WebStackPage/WebStackPage.github.io) 的 [Jekyll](https://jekyllrb.com/) 版。

> 这是一个纯静态的网址导航网站，内容均由 [viggo](http://viggoz.com/) 收集并整理。项目基于bootstrap前端框架开发。

![](https://webstack.0xl2oot.cn/assets/images/preview.gif)
